# DragonRuby Game Toolkit - Asked Questions, Comments, and Concerns

Here are questions, comments, and concerns that frequently come
up about DragonRuby Game Toolkit.

## Frequently Asked Questions

### What is DragonRuby Game Toolkit?

DragonRuby Game Toolkit (or GTK for short),
